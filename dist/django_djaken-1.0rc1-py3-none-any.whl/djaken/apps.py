from django.apps import AppConfig


class DjakenConfig(AppConfig):
    name = 'djaken'
